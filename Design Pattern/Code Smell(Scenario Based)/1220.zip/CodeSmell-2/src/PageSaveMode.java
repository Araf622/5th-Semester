public class PageSaveMode extends PrintMode{

    public void savePage() {

    };

    @Override
    public void makeConfiguration(){
        savePage();
    }

    public void renderPreview(){

    };
}
