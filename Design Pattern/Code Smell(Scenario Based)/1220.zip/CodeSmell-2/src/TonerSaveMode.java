public class TonerSaveMode extends PrintMode{
    String tonerSavingLevel;

    @Override
    public void makeConfiguration() {
        saveToner(tonerSavingLevel);
    }
    public void saveToner(String tonerSavingLevel){
        this.tonerSavingLevel = tonerSavingLevel;
    }
}
