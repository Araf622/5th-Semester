public class PrioritySetting {//Black Sheep
    String priorityLevel;
    public void changePriority(String priorityLevel){
         this.priorityLevel=priorityLevel;
    }
}
