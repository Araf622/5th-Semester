import java.util.ArrayList;

public class PrintJob {
    PrintRequest printRequest = new PrintRequest(new Document(), new TonerSaveMode(), new PageSaveMode(), new BoosterMode());
    ArrayList<PrintRequest> printRequests = new ArrayList<PrintRequest>();
    public void pullJob(){

    }
}
