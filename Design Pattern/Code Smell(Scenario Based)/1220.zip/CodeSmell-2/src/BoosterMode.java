public class BoosterMode extends PrintMode{
    @Override
    public void makeConfiguration(){
        boost();
    }
    public void boost() {

    }


}
