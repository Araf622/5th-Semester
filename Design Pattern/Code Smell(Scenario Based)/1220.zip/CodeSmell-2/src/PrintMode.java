public abstract class PrintMode {
    //Refused Bequest
    public abstract void makeConfiguration();
}
