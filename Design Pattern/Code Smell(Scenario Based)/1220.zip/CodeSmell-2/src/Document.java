public class Document {//Lazy Class
    public int numberOfPages;
    public int pageSize;
    public String orientation;
    public String colorIntensity;
    public String costPerPage;

}
